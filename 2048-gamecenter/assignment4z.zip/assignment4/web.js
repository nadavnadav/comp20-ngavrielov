var express = require("express");
var logfmt = require("logfmt");
var app = express();
var path = require('path');
app.use('/public', express.static(path.join(__dirname + '/public')));


var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';
var mongo = require('mongodb'); // an object we got from a package that will allow us to interact with our db
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	if (error) console.log(error)
	db = databaseConnection;
});

//CORS middleware from http://stackoverflow.com/questions/7067966/how-to-allow-cors-in-express-nodejs
var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}

app.use(logfmt.requestLogger());
app.use(express.json());
app.use(express.urlencoded());
app.use(allowCrossDomain);


app.get('/', function(req, res){
	db.collection("scores", function (er, collection){
		collection.find().sort({'score': -1}).toArray(function(err, results) {
	    //console.log(results);
	    var final_string = '<head><link rel="stylesheet" href="/public/styles.css"></head><h1>Score Center</h1><table><tr><td>Username</td><td>Score</td><td>Time</td></tr>';
	    for (i = 0; i < results.length; i++)
	    {
	    	final_string += ("<tr><td>" + results[i].username + "</td>" + "<td>" + results[i].score + "</td>" + "<td>" + results[i].created_at + "</td>");
		}
		res.send(final_string);
		});
	});

});

app.get('/scores.json', function(req, res){
	var username = req.query.username;
	empty_array = [];
	if (username == null)
	{
		res.send(empty_array);
	}

	db.collection("scores", function (er, collection){
		collection.find({'username': username}).sort({'score': -1}).toArray(function(err, results) {
	    //console.log(results);
	    var scores_json = results;
	    res.send(scores_json);
		});
	});
});

app.post('/submit.json', function(req, res){
	var username = req.body.username;
	var score = parseInt(req.body.score);
	var grid = req.body.grid;
	var date = new Date();
	var created_at = date.toString();

	if (username == null || score == null || grid == null){
		res.send(400);
	}
	//console.log(username);
	//console.log(score);
	//console.log(grid);
	//console.log(created_at);
	
	db.collection("scores", function (er, collection){
    	collection.insert({"username": username, "score": score, "grid": grid, "created_at": created_at}, function (err, r){
    		res.send(200); //it worked
    	});
    });
});



var port = Number(process.env.PORT || 5000);
app.listen(port, function(){
	//console.log("Listening on " + port);
});